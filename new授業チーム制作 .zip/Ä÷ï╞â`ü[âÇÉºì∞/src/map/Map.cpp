#include "Map.h"

Map::Map():
stage_img("res/m_space.png")
{
	SetUp();
}

void Map::SetUp()
{
	pos = Vec2f(0, 0);
	size = Vec2f(32, 32);
	map_text = "res/map.txt";
}

void Map::UpDate()
{



}

void Map::Draw()
{

}