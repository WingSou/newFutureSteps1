#pragma once
#include "../basicrelated/Common.h"

#define MAP_WIDTH 50
#define MAP_HEIGHT 50

class Map
{
public:

	Map();
	void SetUp();
	void Draw();
	void UpDate();

private:

	Vec2f pos;
	Vec2f size;

	int map_number[MAP_HEIGHT][MAP_WIDTH];
	const char* map_text;
	std::ifstream* map_data;

	Texture stage_img;
};