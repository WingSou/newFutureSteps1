﻿
#pragma once

enum Window {
	WIDTH = 2048,
	HEIGHT = 1500
};
