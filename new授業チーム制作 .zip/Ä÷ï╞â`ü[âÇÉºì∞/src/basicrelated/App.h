﻿#pragma once

class App
{
public:
	App();
	static std::shared_ptr<AppEnv> env;

private:
};

