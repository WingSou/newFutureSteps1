#pragma once
#include "Common.h"

class TimeCount
{
public:

	TimeCount();
	void SetUp();
	bool timeCounter(float time);
	int getTimeCount();
private:

	int time_count;


};
