﻿#pragma once
#include "../basicrelated/Common.h"
#include"../basicrelated/Clip.h"
#include "../AI/AI.h"
#include "../Attack/Attack.h"

class Character{
public:

	bool isActive(){
		return is_active;
	}

protected:

	Vec2f pos;
	Vec2f size;
	Vec2f velocity;
	Vec2f speed;
	bool is_active;

	int hp;
	int animation_count;
	int animation_index;
	int x_offset, y_offset;

	AI ai;
	Attack attack;
	Clip clip;
	Random rand;
};